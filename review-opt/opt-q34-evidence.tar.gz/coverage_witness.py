import sys,json,math
sys.path.insert(0,'/Users/flower/math/2026/B题/B')
import numpy as np
import bounded_candidates as bc
out={}
for problem in (3,4):
    stations=next(iter(bc.load_paths(problem).values()));witness={}
    # Each found witness is checked directly with strict margins, not a certificate by sample exhaustion.
    for radius in np.linspace(0,1800,91):
        for theta in np.linspace(0,2*np.pi,360,endpoint=False):
            g=radius*np.array([np.cos(theta),np.sin(theta)]);delta=stations-g;d=np.linalg.norm(delta,axis=1);within=d<=1000.+1e-5
            if problem==3:
                orientations=[None]
            else:orientations=np.linspace(0,2*np.pi,72,endpoint=False)
            for yaw in orientations:
                facing=np.ones(len(stations),bool) if yaw is None else delta@np.array([np.cos(yaw),np.sin(yaw)])>=-1e-5
                visible=np.flatnonzero(within & facing)
                if len(visible)==1:
                    idx=int(visible[0])
                    if idx not in witness:witness[idx]=dict(g=g.tolist(),yaw=None if yaw is None else float(yaw),radius=1000.,visible=idx)
            if len(witness)==len(stations):break
        if len(witness)==len(stations):break
    out[problem]=witness;print(problem,len(witness),'of',len(stations),flush=True)
open('/tmp/q34-opt-20260912/coverage-witness.json','w').write(json.dumps(out,indent=2))
